let arvores = [];
let maquinas = [];
let caminhao;
let laranjasColhidas = 0;
let laranjasNaFabrica = 0;
let numArvores = 10;
let colheitaAtiva = true;
let botao;

function setup() {
  createCanvas(1000, 500);

  for (let i = 0; i < numArvores; i++) {
    let laranjas = [];
    for (let j = 0; j < 6; j++) {
      laranjas.push({
        x: random(-15, 15),
        y: random(-15, 15),
        colhida: false,
        tempoParaCrescer: 0
      });
    }
    arvores.push({
      x: 80 + i * 75,
      y: 250,
      laranjas: laranjas
    });
  }

  for (let i = 0; i < 2; i++) {
    maquinas.push({
      x: -i * 100,
      y: 400,
      speed: 2,
      carregando: 0
    });
  }

  caminhao = {
    x: 1000,
    y: 320,
    carregando: 0,
    indoParaFabrica: false,
    ativo: true,
    velocidade: 1.5
  };

  botao = createButton('Pausar Colheita');
  botao.position(20, 20);
  botao.mousePressed(toggleColheita);
}

function draw() {
  background(180, 230, 180);
  let tempoAtual = millis();

  drawSilo();
  drawFabrica();
  drawArvores(tempoAtual);
  updateMaquinas();
  updateCaminhao();
  drawInfo();
}

function toggleColheita() {
  colheitaAtiva = !colheitaAtiva;
  botao.html(colheitaAtiva ? 'Pausar Colheita' : 'Iniciar Colheita');
}

function drawSilo() {
  fill(160);
  rect(800, 130, 60, 200);
  fill(0);
  textAlign(CENTER);
  textSize(14);
  text("SILO", 830, 120);
  fill(255, 140, 0);
  for (let i = 0; i < laranjasColhidas; i++) {
    let px = 805 + (i % 5) * 10;
    let py = 310 - floor(i / 5) * 10;
    ellipse(px, py, 8, 8);
    if (py < 140) break;
  }
}

function drawFabrica() {
  fill(100);
  rect(50, 120, 100, 180);
  fill(255);
  textAlign(CENTER);
  text("FÁBRICA", 100, 110);
  text("Suco 🍹", 100, 140);

  fill(255, 140, 0);
  for (let i = 0; i < laranjasNaFabrica; i++) {
    let px = 60 + (i % 5) * 10;
    let py = 280 - floor(i / 5) * 10;
    ellipse(px, py, 6, 6);
    if (py < 140) break;
  }
}

function drawArvores(tempoAtual) {
  for (let arvore of arvores) {
    fill(101, 67, 33);
    rect(arvore.x - 5, arvore.y, 10, 40);
    fill(34, 139, 34);
    ellipse(arvore.x, arvore.y, 60, 60);

    for (let laranja of arvore.laranjas) {
      // Se colhida, verificar se deve crescer
      if (laranja.colhida) {
        if (tempoAtual - laranja.tempoParaCrescer > 5000) { // 5 segundos
          laranja.colhida = false;
        }
      }

      // Desenhar somente se não estiver colhida
      if (!laranja.colhida) {
        fill(255, 140, 0);
        ellipse(arvore.x + laranja.x, arvore.y + laranja.y, 6, 6);
      }
    }
  }
}

function updateMaquinas() {
  for (let maquina of maquinas) {
    fill(70, 100, 255);
    rect(maquina.x, maquina.y, 50, 25);
    fill(100);
    ellipse(maquina.x + 10, maquina.y + 25, 15);
    ellipse(maquina.x + 40, maquina.y + 25, 15);

    fill(255, 140, 0);
    for (let i = 0; i < maquina.carregando; i++) {
      ellipse(maquina.x + 5 + (i % 5) * 8, maquina.y - 5 - floor(i / 5) * 8, 6, 6);
    }

    if (colheitaAtiva) {
      maquina.x += maquina.speed;

      for (let arvore of arvores) {
        if (abs(maquina.x - arvore.x) < 20) {
          for (let laranja of arvore.laranjas) {
            if (!laranja.colhida && maquina.carregando < 15) {
              laranja.colhida = true;
              laranja.tempoParaCrescer = millis();
              maquina.carregando++;
            }
          }
        }
      }

      if (maquina.x > 800 && maquina.carregando > 0) {
        laranjasColhidas += maquina.carregando;
        maquina.carregando = 0;
      }

      if (maquina.x > width) {
        maquina.x = -60;
      }
    }
  }
}

function updateCaminhao() {
  fill(255, 0, 0);
  rect(caminhao.x, caminhao.y, 80, 30);
  fill(100);
  ellipse(caminhao.x + 15, caminhao.y + 30, 20);
  ellipse(caminhao.x + 65, caminhao.y + 30, 20);

  fill(255, 140, 0);
  for (let i = 0; i < caminhao.carregando; i++) {
    ellipse(caminhao.x + 10 + (i % 5) * 10, caminhao.y - 5 - floor(i / 5) * 8, 6, 6);
  }

  if (caminhao.ativo) {
    if (!caminhao.indoParaFabrica && caminhao.x > 790 && laranjasColhidas >= 10) {
      caminhao.carregando = 10;
      laranjasColhidas -= 10;
      caminhao.indoParaFabrica = true;
    }

    if (caminhao.indoParaFabrica) {
      caminhao.x -= caminhao.velocidade;
      if (caminhao.x < 150) {
        laranjasNaFabrica += caminhao.carregando;
        caminhao.carregando = 0;
        caminhao.indoParaFabrica = false;
      }
    } else {
      caminhao.x += caminhao.velocidade;
      if (caminhao.x > width + 100) {
        caminhao.x = 1000;
      }
    }
  }
}

function drawInfo() {
  fill(0);
  textSize(16);
  textAlign(LEFT);
  text("Laranjas no silo: " + laranjasColhidas, 20, 60);
  text("Laranjas na fábrica: " + laranjasNaFabrica, 20, 80);
}